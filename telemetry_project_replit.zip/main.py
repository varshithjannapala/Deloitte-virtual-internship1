import json
from datetime import datetime

# Converts ISO timestamp to milliseconds
def convert_iso_to_millis(iso_timestamp):
    dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
    millis = int(dt.timestamp() * 1000)
    return millis

# Merges data from both JSON sources into the unified format
def merge_telemetry(data1, data2):
    unified_data = []

    for entry in data1:
        unified_entry = {
            "device_id": entry["device_id"],
            "timestamp": convert_iso_to_millis(entry["timestamp"]),
            "location": entry["location"],
            "temperature": entry["temperature"]
        }
        unified_data.append(unified_entry)

    for entry in data2:
        unified_entry = {
            "device_id": entry["device_id"],
            "timestamp": entry["timestamp"],
            "location": entry["location"],
            "temperature": entry["temperature"]
        }
        unified_data.append(unified_entry)

    unified_data.sort(key=lambda x: x["timestamp"])

    return unified_data

def main():
    with open('data-1.json') as f:
        data1 = json.load(f)

    with open('data-2.json') as f:
        data2 = json.load(f)

    unified_data = merge_telemetry(data1, data2)

    with open('output.json', 'w') as f:
        json.dump(unified_data, f, indent=2)

    print("Unified data written to output.json")

if __name__ == "__main__":
    main()
